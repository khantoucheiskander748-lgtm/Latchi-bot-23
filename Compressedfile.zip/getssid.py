from pyquotex.stable_api import Quotex
import asyncio

EMAIL = "wagife9306@mugstock.com"
PASSWORD = "latchi23@@"

async def get_ssid():
    client = Quotex(email=EMAIL, password=PASSWORD, lang="en")
    connected, reason = await client.connect()

    print("CONNECTED:", connected, reason)

    try:
        # نحاول نجيب الكوكيز الداخلية
        cookies = client.api.session.cookies.get_dict()
        print("ALL COOKIES =>", cookies)

        if "SSID" in cookies:
            print("SSID =", cookies["SSID"])
        elif "ssid" in cookies:
            print("SSID =", cookies["ssid"])
        else:
            print("SSID NOT FOUND, print full object above.")

    except Exception as e:
        print("COOKIE ERROR:", e)

asyncio.run(get_ssid())